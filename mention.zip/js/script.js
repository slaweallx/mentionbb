/*
Template Name    : Glan - One Page Portfolio Bootstarp 4
Version          : 1.0.0
Author           : SVYYAT
Author URI       : https://themeforest.net/user/svyyat
Created.         : May 2018
File Description : June JS file of the template

// ------------------------------------------ //
//              Table Of Content              //
// ------------------------------------------ //

1. Preloader
2. Navbar
3. Change Theme
4. Smooth Scroll
5. Typed Text
6. Portfolio (Isotope)
7. Magnific Popup
8. Ajax Contact Form
9. activate WOW.js
*/

$(function() {
	'use strict';

	/*========== Start Preloader ==========*/

	$('.preloader').delay(500).fadeOut('slow');

	/*========== End Preloader ==========*/
	/*========== Start Navbar ==========*/

	$('nav a').on('click', function() {
		$('nav a').removeClass('active');
		$(this).addClass('active')
	});

	$(window).on('scroll', function(){
		if ($(window).scrollTop() > 50) {
			$('header').addClass('sticky');
		} else {
			$('header').removeClass('sticky');
		}
	});

	$('body').scrollspy({
		offset: 80
	});

	/*========== End Navbar ==========*/
	/*========== Start Change Theme ==========*/

	$(".theme a").on('click', function() {
		$(".theme a").removeClass("active-theme");
		$(this).addClass("active-theme");
	});

	$('#day').on('click', function (){
		$('head link#theme').attr('href',$(this).data("theme"));
	});
	$('#night').on('click', function (){
		$('head link#theme').attr('href',$(this).data("theme"));
	});

	/*========== End Change Theme ==========*/
	/*========== Start Smooth Scroll ==========*/

	$('a[href*="#"]').on('click', function (e) {
		e.preventDefault();
		$('html, body').animate({
			scrollTop: $($(this).attr('href')).offset().top - 0
		}, 1200, 'easeInOutCubic');
	});

	/*========== End Smooth Scroll ==========*/
	/*========== Start Typed Text ==========*/

	var proff = {
		strings: ['Photographer', 'Graphic Desinger', 'Web Desinger'],
		typeSpeed: 100,
		startDelay: 1500,
		backDelay: 2000,
		fadeOut: true,
		loop: true
	}

	var typed = new Typed('.proff', proff);

	/*========== End Typed Text ==========*/

	$(window).on('scroll', function () {
		$(".progress-bar").each(function () {
			var bottom_of_object = 
			$(this).offset().top + $(this).outerHeight();
			var bottom_of_window = 
			$(window).scrollTop() + $(window).height();
			var myVal = $(this).attr('data-value');
			if(bottom_of_window > bottom_of_object) {
				$(this).css({
					width : myVal
				});
			}
		});
	});

	/*========== Start Counter (Statistic) ==========*/

	$('.counter').countUp({
		delay: 8,
		time: 1000
	});

	/*========== End Counter (Statistic) ==========*/

	/*========== Start Project (Isotope) ==========*/

	$('.filter li a').on('click', function() {
		$('.filter li a').removeClass('active-f');
		$(this).addClass('active-f')
	});

	$('.portfolio-container').isotope({
		itemSelector: '.portfolio-item',
		layoutMode: 'fitRows'
	});

	var $gallery = $('.portfolio-container').isotope();

	$('.filter li a').on( 'click', function() {
		var filterValue = $(this).attr('data-filter');
		$gallery.isotope({ filter: filterValue });
	});

	/*========== End Project (Isotope) ==========*/
	/*========== Start Magnific Popup ==========*/

	$('.portfolio-item a').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			gallery: {
				enabled: true,
				preload: [0, 1]
			},
		});

	/*========== End Magnific Popup ==========*/
	/*========== Start Ajax Contact Form ==========*/

	$('#form').on('submit', function() {
		$.ajax({
			type: 'POST',
			url: 'mail.php', // default 'mail.php'. Can be change to 'telegram.php' for using Telegram
			data: $(this).serialize(),
			success: function (data)
			{
				$(this).find('input').val('');
				alert('Thank you for your request! Soon we will contact you.');
				$('#form').trigger('reset');
			}
		});
		return false;
	});

	/*========== End Ajax Contact Form ==========*/

});

/*========== Start activate WOW.js ==========*/

$(function() {
	'use strict';

	new WOW().init();

});

/*========== End activate WOW.js ==========*/